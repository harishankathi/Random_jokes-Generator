const jokeContainer = document.getElementById("joke");
const btn = document.getElementById("btn");
const url =
  "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,sexist,explicit&type=single";

let getjoke = () => {
  fetch(url)
    .then((res) => res.json())
    .then((item) => {
      jokeContainer.innerHTML = item.joke;
    });
};
;
